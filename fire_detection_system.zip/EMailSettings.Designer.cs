﻿
namespace WindowsFormsApp1
{
    partial class EMailSettings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EMailSettings));
            this.guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            this.BtnOK = new Guna.UI2.WinForms.Guna2Button();
            this.TBUserName = new Guna.UI2.WinForms.Guna2TextBox();
            this.TBPassword = new Guna.UI2.WinForms.Guna2TextBox();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider2 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider3 = new System.Windows.Forms.ErrorProvider(this.components);
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.TBEMailAdress = new Guna.UI2.WinForms.Guna2TextBox();
            this.TBServerAddress = new Guna.UI2.WinForms.Guna2TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // guna2Button1
            // 
            this.guna2Button1.Animated = true;
            this.guna2Button1.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button1.BorderRadius = 8;
            this.guna2Button1.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button1.ForeColor = System.Drawing.Color.White;
            this.guna2Button1.Location = new System.Drawing.Point(12, 476);
            this.guna2Button1.Name = "guna2Button1";
            this.guna2Button1.Size = new System.Drawing.Size(52, 36);
            this.guna2Button1.TabIndex = 24;
            this.guna2Button1.Text = "Back";
            this.guna2Button1.UseTransparentBackground = true;
            this.guna2Button1.Click += new System.EventHandler(this.guna2Button1_Click);
            // 
            // BtnOK
            // 
            this.BtnOK.Animated = true;
            this.BtnOK.BackColor = System.Drawing.Color.Transparent;
            this.BtnOK.BorderRadius = 8;
            this.BtnOK.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.BtnOK.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.BtnOK.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.BtnOK.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.BtnOK.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.BtnOK.ForeColor = System.Drawing.Color.White;
            this.BtnOK.Location = new System.Drawing.Point(221, 367);
            this.BtnOK.Name = "BtnOK";
            this.BtnOK.Size = new System.Drawing.Size(70, 36);
            this.BtnOK.TabIndex = 22;
            this.BtnOK.Text = "OK";
            this.BtnOK.UseTransparentBackground = true;
            this.BtnOK.Click += new System.EventHandler(this.BtnOK_Click);
            // 
            // TBUserName
            // 
            this.TBUserName.Animated = true;
            this.TBUserName.BackColor = System.Drawing.Color.Transparent;
            this.TBUserName.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.TBUserName.BorderColor = System.Drawing.Color.White;
            this.TBUserName.BorderRadius = 8;
            this.TBUserName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TBUserName.DefaultText = "";
            this.TBUserName.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.TBUserName.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.TBUserName.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TBUserName.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TBUserName.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.TBUserName.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TBUserName.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TBUserName.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TBUserName.Location = new System.Drawing.Point(144, 252);
            this.TBUserName.Name = "TBUserName";
            this.TBUserName.PasswordChar = '\0';
            this.TBUserName.PlaceholderForeColor = System.Drawing.Color.White;
            this.TBUserName.PlaceholderText = "Username ";
            this.TBUserName.SelectedText = "";
            this.TBUserName.Size = new System.Drawing.Size(222, 36);
            this.TBUserName.TabIndex = 19;
            // 
            // TBPassword
            // 
            this.TBPassword.Animated = true;
            this.TBPassword.BackColor = System.Drawing.Color.Transparent;
            this.TBPassword.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.TBPassword.BorderColor = System.Drawing.Color.White;
            this.TBPassword.BorderRadius = 8;
            this.TBPassword.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TBPassword.DefaultText = "";
            this.TBPassword.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.TBPassword.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.TBPassword.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TBPassword.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TBPassword.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.TBPassword.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TBPassword.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TBPassword.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TBPassword.Location = new System.Drawing.Point(144, 313);
            this.TBPassword.Name = "TBPassword";
            this.TBPassword.PasswordChar = '*';
            this.TBPassword.PlaceholderForeColor = System.Drawing.Color.White;
            this.TBPassword.PlaceholderText = "Password";
            this.TBPassword.SelectedText = "";
            this.TBPassword.Size = new System.Drawing.Size(222, 36);
            this.TBPassword.TabIndex = 20;
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // errorProvider2
            // 
            this.errorProvider2.ContainerControl = this;
            // 
            // errorProvider3
            // 
            this.errorProvider3.ContainerControl = this;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(116, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(296, 78);
            this.pictureBox1.TabIndex = 25;
            this.pictureBox1.TabStop = false;
            // 
            // TBEMailAdress
            // 
            this.TBEMailAdress.Animated = true;
            this.TBEMailAdress.BackColor = System.Drawing.Color.Transparent;
            this.TBEMailAdress.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.TBEMailAdress.BorderColor = System.Drawing.Color.White;
            this.TBEMailAdress.BorderRadius = 8;
            this.TBEMailAdress.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TBEMailAdress.DefaultText = "";
            this.TBEMailAdress.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.TBEMailAdress.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.TBEMailAdress.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TBEMailAdress.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TBEMailAdress.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.TBEMailAdress.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TBEMailAdress.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TBEMailAdress.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TBEMailAdress.Location = new System.Drawing.Point(144, 195);
            this.TBEMailAdress.Name = "TBEMailAdress";
            this.TBEMailAdress.PasswordChar = '\0';
            this.TBEMailAdress.PlaceholderForeColor = System.Drawing.Color.White;
            this.TBEMailAdress.PlaceholderText = "EMail Address";
            this.TBEMailAdress.SelectedText = "";
            this.TBEMailAdress.Size = new System.Drawing.Size(222, 36);
            this.TBEMailAdress.TabIndex = 19;
            // 
            // TBServerAddress
            // 
            this.TBServerAddress.Animated = true;
            this.TBServerAddress.BackColor = System.Drawing.Color.Transparent;
            this.TBServerAddress.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.TBServerAddress.BorderColor = System.Drawing.Color.White;
            this.TBServerAddress.BorderRadius = 8;
            this.TBServerAddress.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TBServerAddress.DefaultText = "";
            this.TBServerAddress.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.TBServerAddress.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.TBServerAddress.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TBServerAddress.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TBServerAddress.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.TBServerAddress.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TBServerAddress.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TBServerAddress.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TBServerAddress.Location = new System.Drawing.Point(144, 136);
            this.TBServerAddress.Name = "TBServerAddress";
            this.TBServerAddress.PasswordChar = '\0';
            this.TBServerAddress.PlaceholderForeColor = System.Drawing.Color.White;
            this.TBServerAddress.PlaceholderText = "SMTP Server Address";
            this.TBServerAddress.SelectedText = "";
            this.TBServerAddress.Size = new System.Drawing.Size(222, 36);
            this.TBServerAddress.TabIndex = 19;
            // 
            // EMailSettings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(512, 524);
            this.Controls.Add(this.guna2Button1);
            this.Controls.Add(this.BtnOK);
            this.Controls.Add(this.TBServerAddress);
            this.Controls.Add(this.TBEMailAdress);
            this.Controls.Add(this.TBUserName);
            this.Controls.Add(this.TBPassword);
            this.Controls.Add(this.pictureBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(528, 563);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(528, 563);
            this.Name = "EMailSettings";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "EMailSettings";
            this.Load += new System.EventHandler(this.EMailSettings_Load);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private Guna.UI2.WinForms.Guna2Button BtnOK;
        private Guna.UI2.WinForms.Guna2TextBox TBUserName;
        private Guna.UI2.WinForms.Guna2TextBox TBPassword;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ErrorProvider errorProvider2;
        private System.Windows.Forms.ErrorProvider errorProvider3;
        private Guna.UI2.WinForms.Guna2TextBox TBEMailAdress;
        private Guna.UI2.WinForms.Guna2TextBox TBServerAddress;
    }
}