﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AForge.Video;
using AForge.Video.DirectShow;
using AForge;
using Yolov5Net.Scorer;
using Yolov5Net.Scorer.Models;

namespace WindowsFormsApp1
{
    public partial class stream : Form
    {
        DateTime LastSend=DateTime.MinValue;
        int flag = -1;
        public stream()
        {
            InitializeComponent();
            getAllcameralist();
        }

        FilterInfoCollection capture_device;
        VideoCaptureDevice Video_device;

        //get list of connected devices or options
        void getAllcameralist()
        {
            capture_device = new FilterInfoCollection(FilterCategory.VideoInputDevice);
            foreach (FilterInfo devices in capture_device)
                camera_cbo.Items.Add(devices.Name);
        }


        private void stream_Load(object sender, EventArgs e)
        {
            cam_btn_panel.Hide();
            //axWindowsMediaPlayer1.Hide();


            //show current username
          username_label.Text = Properties.Settings.Default.Username;
            //show current username
        }

        //connect button
        private void guna2Button1_Click(object sender, EventArgs e)
        {
            // hide and show camera pannel buttons
            flag *= -1;
            if (flag == 1)
                cam_btn_panel.Hide();
            else
                cam_btn_panel.Show();
        }

        //start webcam camera button///////////////
        private void guna2Button3_Click(object sender, EventArgs e)
        {
            try
                {
                Video_device = new VideoCaptureDevice(capture_device[camera_cbo.SelectedIndex].MonikerString);
                Video_device.NewFrame += new NewFrameEventHandler(NewVideoFrame);
                Video_device.Start();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // NewVideoFrame function /////
        private void NewVideoFrame(object sender, NewFrameEventArgs eventArgs)
        {
            PictureBox1.Image =Detector.Detect((Bitmap) eventArgs.Frame.Clone(), true);
        }
        


        
        

        //stop button
        private void guna2Button4_Click(object sender, EventArgs e)
        {
            
                if (Video_device.IsRunning == true)
                {
                    Video_device.Stop();
                }
                else
            {
                MessageBox.Show("Error!!");
            }
         
            
               

        
            //try
            //{
            //    Video_device.Stop();
            //}
            //catch (Exception ex1)
            //{
            //    MessageBox.Show(ex1.Message);
            //}

        }

        //add video button
        private void guna2Button2_Click(object sender, EventArgs e)
        {
            add_video ss= new add_video();
            ss.Show();

        }

  


        //change password button
        private void guna2Button1_Click_1(object sender, EventArgs e)
        {
            change_pass cg = new change_pass();
            this.Hide();
            cg.ShowDialog();

        }

        // user detail button
        private void guna2Button6_Click(object sender, EventArgs e)
        {
            user_detail_form ug = new user_detail_form();
            this.Hide();
            ug.ShowDialog();
        }


        //logout button
        private void guna2Button7_Click(object sender, EventArgs e)
        {
            this.Hide();
            Loginn nm = new Loginn();
            nm.ShowDialog();
        }

        private void guna2Button5_Click(object sender, EventArgs e)
        {
            var Settings = new EMailSettings().ShowDialog(this);
        }

        private void BtnDetectImage_Click(object sender, EventArgs e)
        {
            var DetectImageForm = new DetectImage().ShowDialog(this);
        }
    }
}
