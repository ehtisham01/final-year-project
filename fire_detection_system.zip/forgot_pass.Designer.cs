﻿
namespace WindowsFormsApp1
{
    partial class forgot_pass
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(forgot_pass));
            this.change_Button = new Guna.UI2.WinForms.Guna2Button();
            this.f_confirm_pas = new Guna.UI2.WinForms.Guna2TextBox();
            this.f_username_tb = new Guna.UI2.WinForms.Guna2TextBox();
            this.f_password_tb = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider2 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider3 = new System.Windows.Forms.ErrorProvider(this.components);
            this.check_box_pas_forgot = new System.Windows.Forms.CheckBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // change_Button
            // 
            this.change_Button.Animated = true;
            this.change_Button.BackColor = System.Drawing.Color.Transparent;
            this.change_Button.BorderRadius = 8;
            this.change_Button.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.change_Button.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.change_Button.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.change_Button.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.change_Button.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.change_Button.ForeColor = System.Drawing.Color.White;
            this.change_Button.Location = new System.Drawing.Point(198, 381);
            this.change_Button.Name = "change_Button";
            this.change_Button.Size = new System.Drawing.Size(108, 36);
            this.change_Button.TabIndex = 9;
            this.change_Button.Text = "Change";
            this.change_Button.UseTransparentBackground = true;
            this.change_Button.Click += new System.EventHandler(this.change_Button_Click);
            // 
            // f_confirm_pas
            // 
            this.f_confirm_pas.Animated = true;
            this.f_confirm_pas.BackColor = System.Drawing.Color.Transparent;
            this.f_confirm_pas.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.f_confirm_pas.BorderColor = System.Drawing.Color.White;
            this.f_confirm_pas.BorderRadius = 8;
            this.f_confirm_pas.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.f_confirm_pas.DefaultText = "";
            this.f_confirm_pas.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.f_confirm_pas.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.f_confirm_pas.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.f_confirm_pas.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.f_confirm_pas.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.f_confirm_pas.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.f_confirm_pas.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.f_confirm_pas.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.f_confirm_pas.Location = new System.Drawing.Point(139, 285);
            this.f_confirm_pas.Name = "f_confirm_pas";
            this.f_confirm_pas.PasswordChar = '*';
            this.f_confirm_pas.PlaceholderForeColor = System.Drawing.Color.White;
            this.f_confirm_pas.PlaceholderText = "Confirm password";
            this.f_confirm_pas.SelectedText = "";
            this.f_confirm_pas.Size = new System.Drawing.Size(222, 36);
            this.f_confirm_pas.TabIndex = 2;
            this.f_confirm_pas.Leave += new System.EventHandler(this.f_confirm_pas_Leave);
            // 
            // f_username_tb
            // 
            this.f_username_tb.Animated = true;
            this.f_username_tb.BackColor = System.Drawing.Color.Transparent;
            this.f_username_tb.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.f_username_tb.BorderColor = System.Drawing.Color.White;
            this.f_username_tb.BorderRadius = 8;
            this.f_username_tb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.f_username_tb.DefaultText = "";
            this.f_username_tb.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.f_username_tb.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.f_username_tb.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.f_username_tb.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.f_username_tb.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.f_username_tb.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.f_username_tb.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.f_username_tb.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.f_username_tb.Location = new System.Drawing.Point(139, 157);
            this.f_username_tb.Name = "f_username_tb";
            this.f_username_tb.PasswordChar = '\0';
            this.f_username_tb.PlaceholderForeColor = System.Drawing.Color.White;
            this.f_username_tb.PlaceholderText = "Username ";
            this.f_username_tb.SelectedText = "";
            this.f_username_tb.Size = new System.Drawing.Size(222, 36);
            this.f_username_tb.TabIndex = 0;
            this.f_username_tb.Leave += new System.EventHandler(this.f_username_tb_Leave);
            // 
            // f_password_tb
            // 
            this.f_password_tb.Animated = true;
            this.f_password_tb.BackColor = System.Drawing.Color.Transparent;
            this.f_password_tb.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.f_password_tb.BorderColor = System.Drawing.Color.White;
            this.f_password_tb.BorderRadius = 8;
            this.f_password_tb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.f_password_tb.DefaultText = "";
            this.f_password_tb.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.f_password_tb.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.f_password_tb.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.f_password_tb.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.f_password_tb.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.f_password_tb.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.f_password_tb.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.f_password_tb.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.f_password_tb.Location = new System.Drawing.Point(139, 221);
            this.f_password_tb.Name = "f_password_tb";
            this.f_password_tb.PasswordChar = '*';
            this.f_password_tb.PlaceholderForeColor = System.Drawing.Color.White;
            this.f_password_tb.PlaceholderText = "Password";
            this.f_password_tb.SelectedText = "";
            this.f_password_tb.Size = new System.Drawing.Size(222, 36);
            this.f_password_tb.TabIndex = 1;
            this.f_password_tb.Leave += new System.EventHandler(this.f_password_tb_Leave);
            // 
            // guna2Button1
            // 
            this.guna2Button1.Animated = true;
            this.guna2Button1.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button1.BorderRadius = 8;
            this.guna2Button1.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button1.ForeColor = System.Drawing.Color.White;
            this.guna2Button1.Location = new System.Drawing.Point(12, 476);
            this.guna2Button1.Name = "guna2Button1";
            this.guna2Button1.Size = new System.Drawing.Size(52, 36);
            this.guna2Button1.TabIndex = 10;
            this.guna2Button1.Text = "Back";
            this.guna2Button1.UseTransparentBackground = true;
            this.guna2Button1.Click += new System.EventHandler(this.guna2Button1_Click);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // errorProvider2
            // 
            this.errorProvider2.ContainerControl = this;
            // 
            // errorProvider3
            // 
            this.errorProvider3.ContainerControl = this;
            // 
            // check_box_pas_forgot
            // 
            this.check_box_pas_forgot.AutoSize = true;
            this.check_box_pas_forgot.BackColor = System.Drawing.Color.Transparent;
            this.check_box_pas_forgot.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.check_box_pas_forgot.ForeColor = System.Drawing.Color.White;
            this.check_box_pas_forgot.Location = new System.Drawing.Point(139, 341);
            this.check_box_pas_forgot.Name = "check_box_pas_forgot";
            this.check_box_pas_forgot.Size = new System.Drawing.Size(108, 19);
            this.check_box_pas_forgot.TabIndex = 11;
            this.check_box_pas_forgot.Text = "Show password";
            this.check_box_pas_forgot.UseVisualStyleBackColor = false;
            this.check_box_pas_forgot.CheckedChanged += new System.EventHandler(this.check_box_pas_forgot_CheckedChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(105, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(296, 78);
            this.pictureBox1.TabIndex = 12;
            this.pictureBox1.TabStop = false;
            // 
            // forgot_pass
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(512, 524);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.check_box_pas_forgot);
            this.Controls.Add(this.guna2Button1);
            this.Controls.Add(this.change_Button);
            this.Controls.Add(this.f_confirm_pas);
            this.Controls.Add(this.f_username_tb);
            this.Controls.Add(this.f_password_tb);
            this.ForeColor = System.Drawing.Color.White;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(528, 563);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(528, 563);
            this.Name = "forgot_pass";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Forgot password";
            this.Load += new System.EventHandler(this.forgot_pass_Load);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2Button change_Button;
        private Guna.UI2.WinForms.Guna2TextBox f_confirm_pas;
        private Guna.UI2.WinForms.Guna2TextBox f_username_tb;
        private Guna.UI2.WinForms.Guna2TextBox f_password_tb;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.ErrorProvider errorProvider2;
        private System.Windows.Forms.ErrorProvider errorProvider3;
        private System.Windows.Forms.CheckBox check_box_pas_forgot;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}