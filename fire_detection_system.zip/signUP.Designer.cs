﻿
namespace WindowsFormsApp1
{
    partial class signUP
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(signUP));
            this.guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.email_tb = new Guna.UI2.WinForms.Guna2TextBox();
            this.f_name_tb = new Guna.UI2.WinForms.Guna2TextBox();
            this.confirm_pass_tb = new Guna.UI2.WinForms.Guna2TextBox();
            this.pass_tb = new Guna.UI2.WinForms.Guna2TextBox();
            this.phnum_tb = new Guna.UI2.WinForms.Guna2TextBox();
            this.L_name_tb = new Guna.UI2.WinForms.Guna2TextBox();
            this.username_tb = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider2 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider3 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider4 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider5 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider6 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider7 = new System.Windows.Forms.ErrorProvider(this.components);
            this.guna2Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider7)).BeginInit();
            this.SuspendLayout();
            // 
            // guna2Panel1
            // 
            this.guna2Panel1.Controls.Add(this.pictureBox1);
            this.guna2Panel1.Controls.Add(this.checkBox1);
            this.guna2Panel1.Controls.Add(this.email_tb);
            this.guna2Panel1.Controls.Add(this.f_name_tb);
            this.guna2Panel1.Controls.Add(this.confirm_pass_tb);
            this.guna2Panel1.Controls.Add(this.pass_tb);
            this.guna2Panel1.Controls.Add(this.phnum_tb);
            this.guna2Panel1.Controls.Add(this.L_name_tb);
            this.guna2Panel1.Controls.Add(this.username_tb);
            this.guna2Panel1.Controls.Add(this.guna2Button1);
            this.guna2Panel1.Controls.Add(this.label5);
            this.guna2Panel1.Controls.Add(this.label4);
            this.guna2Panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.guna2Panel1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.guna2Panel1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.guna2Panel1.Location = new System.Drawing.Point(0, 0);
            this.guna2Panel1.MaximumSize = new System.Drawing.Size(837, 610);
            this.guna2Panel1.MinimumSize = new System.Drawing.Size(837, 610);
            this.guna2Panel1.Name = "guna2Panel1";
            this.guna2Panel1.Size = new System.Drawing.Size(837, 610);
            this.guna2Panel1.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(262, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(296, 78);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.BackColor = System.Drawing.Color.Transparent;
            this.checkBox1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox1.ForeColor = System.Drawing.Color.White;
            this.checkBox1.Location = new System.Drawing.Point(290, 458);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(108, 19);
            this.checkBox1.TabIndex = 9;
            this.checkBox1.Text = "Show password";
            this.checkBox1.UseVisualStyleBackColor = false;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // email_tb
            // 
            this.email_tb.Animated = true;
            this.email_tb.BackColor = System.Drawing.Color.Transparent;
            this.email_tb.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.email_tb.BorderColor = System.Drawing.Color.White;
            this.email_tb.BorderRadius = 8;
            this.email_tb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.email_tb.DefaultText = "";
            this.email_tb.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.email_tb.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.email_tb.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.email_tb.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.email_tb.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.email_tb.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.email_tb.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.email_tb.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.email_tb.Location = new System.Drawing.Point(418, 214);
            this.email_tb.Name = "email_tb";
            this.email_tb.PasswordChar = '\0';
            this.email_tb.PlaceholderForeColor = System.Drawing.Color.White;
            this.email_tb.PlaceholderText = "Email";
            this.email_tb.SelectedText = "";
            this.email_tb.Size = new System.Drawing.Size(152, 36);
            this.email_tb.TabIndex = 4;
            this.email_tb.Enter += new System.EventHandler(this.email_tb_Enter);
            this.email_tb.Leave += new System.EventHandler(this.email_tb_Leave);
            // 
            // f_name_tb
            // 
            this.f_name_tb.Animated = true;
            this.f_name_tb.BackColor = System.Drawing.Color.Transparent;
            this.f_name_tb.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.f_name_tb.BorderColor = System.Drawing.Color.White;
            this.f_name_tb.BorderRadius = 8;
            this.f_name_tb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.f_name_tb.DefaultText = "";
            this.f_name_tb.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.f_name_tb.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.f_name_tb.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.f_name_tb.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.f_name_tb.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.f_name_tb.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.f_name_tb.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.f_name_tb.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.f_name_tb.Location = new System.Drawing.Point(237, 148);
            this.f_name_tb.Name = "f_name_tb";
            this.f_name_tb.PasswordChar = '\0';
            this.f_name_tb.PlaceholderForeColor = System.Drawing.Color.White;
            this.f_name_tb.PlaceholderText = "First name";
            this.f_name_tb.SelectedText = "";
            this.f_name_tb.Size = new System.Drawing.Size(152, 36);
            this.f_name_tb.TabIndex = 0;
            this.f_name_tb.Leave += new System.EventHandler(this.f_name_tb_Leave);
            // 
            // confirm_pass_tb
            // 
            this.confirm_pass_tb.Animated = true;
            this.confirm_pass_tb.BackColor = System.Drawing.Color.Transparent;
            this.confirm_pass_tb.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.confirm_pass_tb.BorderColor = System.Drawing.Color.White;
            this.confirm_pass_tb.BorderRadius = 8;
            this.confirm_pass_tb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.confirm_pass_tb.DefaultText = "";
            this.confirm_pass_tb.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.confirm_pass_tb.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.confirm_pass_tb.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.confirm_pass_tb.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.confirm_pass_tb.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.confirm_pass_tb.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.confirm_pass_tb.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.confirm_pass_tb.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.confirm_pass_tb.Location = new System.Drawing.Point(290, 406);
            this.confirm_pass_tb.Name = "confirm_pass_tb";
            this.confirm_pass_tb.PasswordChar = '*';
            this.confirm_pass_tb.PlaceholderForeColor = System.Drawing.Color.White;
            this.confirm_pass_tb.PlaceholderText = "Confrim password";
            this.confirm_pass_tb.SelectedText = "";
            this.confirm_pass_tb.Size = new System.Drawing.Size(222, 36);
            this.confirm_pass_tb.TabIndex = 7;
            this.confirm_pass_tb.Leave += new System.EventHandler(this.confirm_pass_tb_Leave);
            // 
            // pass_tb
            // 
            this.pass_tb.Animated = true;
            this.pass_tb.BackColor = System.Drawing.Color.Transparent;
            this.pass_tb.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pass_tb.BorderColor = System.Drawing.Color.White;
            this.pass_tb.BorderRadius = 8;
            this.pass_tb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.pass_tb.DefaultText = "";
            this.pass_tb.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.pass_tb.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.pass_tb.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.pass_tb.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.pass_tb.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.pass_tb.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.pass_tb.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.pass_tb.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.pass_tb.Location = new System.Drawing.Point(290, 344);
            this.pass_tb.Name = "pass_tb";
            this.pass_tb.PasswordChar = '*';
            this.pass_tb.PlaceholderForeColor = System.Drawing.Color.White;
            this.pass_tb.PlaceholderText = "Password";
            this.pass_tb.SelectedText = "";
            this.pass_tb.Size = new System.Drawing.Size(222, 36);
            this.pass_tb.TabIndex = 6;
            this.pass_tb.Leave += new System.EventHandler(this.pass_tb_Leave);
            // 
            // phnum_tb
            // 
            this.phnum_tb.Animated = true;
            this.phnum_tb.BackColor = System.Drawing.Color.Transparent;
            this.phnum_tb.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.phnum_tb.BorderColor = System.Drawing.Color.White;
            this.phnum_tb.BorderRadius = 8;
            this.phnum_tb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.phnum_tb.DefaultText = "";
            this.phnum_tb.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.phnum_tb.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.phnum_tb.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.phnum_tb.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.phnum_tb.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.phnum_tb.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.phnum_tb.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.phnum_tb.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.phnum_tb.Location = new System.Drawing.Point(290, 280);
            this.phnum_tb.Name = "phnum_tb";
            this.phnum_tb.PasswordChar = '\0';
            this.phnum_tb.PlaceholderForeColor = System.Drawing.Color.White;
            this.phnum_tb.PlaceholderText = "Phone Number";
            this.phnum_tb.SelectedText = "";
            this.phnum_tb.Size = new System.Drawing.Size(222, 36);
            this.phnum_tb.TabIndex = 5;
            this.phnum_tb.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.phnum_tb_KeyPress);
            this.phnum_tb.Leave += new System.EventHandler(this.phnum_tb_Leave);
            // 
            // L_name_tb
            // 
            this.L_name_tb.Animated = true;
            this.L_name_tb.BackColor = System.Drawing.Color.Transparent;
            this.L_name_tb.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.L_name_tb.BorderColor = System.Drawing.Color.White;
            this.L_name_tb.BorderRadius = 8;
            this.L_name_tb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.L_name_tb.DefaultText = "";
            this.L_name_tb.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.L_name_tb.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.L_name_tb.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.L_name_tb.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.L_name_tb.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.L_name_tb.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.L_name_tb.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.L_name_tb.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.L_name_tb.Location = new System.Drawing.Point(418, 148);
            this.L_name_tb.Name = "L_name_tb";
            this.L_name_tb.PasswordChar = '\0';
            this.L_name_tb.PlaceholderForeColor = System.Drawing.Color.White;
            this.L_name_tb.PlaceholderText = "Last name";
            this.L_name_tb.SelectedText = "";
            this.L_name_tb.Size = new System.Drawing.Size(152, 36);
            this.L_name_tb.TabIndex = 2;
            this.L_name_tb.Leave += new System.EventHandler(this.L_name_tb_Leave);
            // 
            // username_tb
            // 
            this.username_tb.Animated = true;
            this.username_tb.BackColor = System.Drawing.Color.Transparent;
            this.username_tb.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.username_tb.BorderColor = System.Drawing.Color.White;
            this.username_tb.BorderRadius = 8;
            this.username_tb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.username_tb.DefaultText = "";
            this.username_tb.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.username_tb.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.username_tb.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.username_tb.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.username_tb.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.username_tb.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.username_tb.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.username_tb.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.username_tb.Location = new System.Drawing.Point(237, 214);
            this.username_tb.Name = "username_tb";
            this.username_tb.PasswordChar = '\0';
            this.username_tb.PlaceholderForeColor = System.Drawing.Color.White;
            this.username_tb.PlaceholderText = "Username";
            this.username_tb.SelectedText = "";
            this.username_tb.Size = new System.Drawing.Size(152, 36);
            this.username_tb.TabIndex = 3;
            this.username_tb.Enter += new System.EventHandler(this.username_tb_Enter);
            this.username_tb.Leave += new System.EventHandler(this.username_tb_Leave);
            // 
            // guna2Button1
            // 
            this.guna2Button1.Animated = true;
            this.guna2Button1.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button1.BorderRadius = 8;
            this.guna2Button1.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button1.ForeColor = System.Drawing.Color.White;
            this.guna2Button1.Location = new System.Drawing.Point(349, 512);
            this.guna2Button1.Name = "guna2Button1";
            this.guna2Button1.Size = new System.Drawing.Size(108, 36);
            this.guna2Button1.TabIndex = 8;
            this.guna2Button1.Text = "signup";
            this.guna2Button1.UseTransparentBackground = true;
            this.guna2Button1.Click += new System.EventHandler(this.guna2Button1_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label5.Font = new System.Drawing.Font("Segoe UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(465, 563);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(61, 15);
            this.label5.TabIndex = 7;
            this.label5.Text = "click here";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label4.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(287, 563);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(182, 15);
            this.label4.TabIndex = 6;
            this.label4.Text = "if you already have account then,";
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // errorProvider2
            // 
            this.errorProvider2.ContainerControl = this;
            // 
            // errorProvider3
            // 
            this.errorProvider3.ContainerControl = this;
            // 
            // errorProvider4
            // 
            this.errorProvider4.ContainerControl = this;
            // 
            // errorProvider5
            // 
            this.errorProvider5.ContainerControl = this;
            // 
            // errorProvider6
            // 
            this.errorProvider6.ContainerControl = this;
            // 
            // errorProvider7
            // 
            this.errorProvider7.ContainerControl = this;
            // 
            // signUP
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(838, 610);
            this.Controls.Add(this.guna2Panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(854, 649);
            this.MinimumSize = new System.Drawing.Size(854, 649);
            this.Name = "signUP";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "signup";
            this.Load += new System.EventHandler(this.signUP_Load);
            this.guna2Panel1.ResumeLayout(false);
            this.guna2Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider7)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private Guna.UI2.WinForms.Guna2TextBox username_tb;
        private Guna.UI2.WinForms.Guna2TextBox pass_tb;
        private Guna.UI2.WinForms.Guna2TextBox phnum_tb;
        private Guna.UI2.WinForms.Guna2TextBox L_name_tb;
        private Guna.UI2.WinForms.Guna2TextBox f_name_tb;
        private Guna.UI2.WinForms.Guna2TextBox email_tb;
        private Guna.UI2.WinForms.Guna2TextBox confirm_pass_tb;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.ErrorProvider errorProvider2;
        private System.Windows.Forms.ErrorProvider errorProvider3;
        private System.Windows.Forms.ErrorProvider errorProvider4;
        private System.Windows.Forms.ErrorProvider errorProvider5;
        private System.Windows.Forms.ErrorProvider errorProvider6;
        private System.Windows.Forms.ErrorProvider errorProvider7;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

