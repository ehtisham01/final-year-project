﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class change_pass : Form
    {
        SqlConnection SqlConnection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\HP\Desktop\try3.0\WindowsFormsApp1\user_details.mdf;Integrated Security=True");

        public change_pass()
        {
            InitializeComponent();
        }

        //back button
        private void guna2Button1_Click(object sender, EventArgs e)
        {
            stream ss = new stream();
            this.Hide();
            ss.ShowDialog();
        }

        private void change_pass_Load(object sender, EventArgs e)
        {
            // to check database connection
            try
            {
                SqlConnection.Open();
            }
            catch
            {
                MessageBox.Show("Connection to the database failed!", "Error", MessageBoxButtons.OK);
            }
            // to check database connection
        }


        //show password box
        private void check_box_pas_forgot_CheckedChanged(object sender, EventArgs e)
        {
            if (check_box_pas_forgot.Checked)
            {
                ch_password_tb.PasswordChar = '\0';
                ch_confirm_pas.PasswordChar = '\0';

            }
            else
            {
                ch_password_tb.PasswordChar = '*';
                ch_confirm_pas.PasswordChar = '*';

            }
        }

        //for username txtbox
        private void ch_username_tb_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(ch_username_tb.Text) == true)
            {

                errorProvider1.SetError(this.ch_username_tb, "please add username!!");
            }
            else
            {
                errorProvider1.Clear();
            }
        }

        //for password textbox
        private void ch_password_tb_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(ch_password_tb.Text) == true)
            {

                errorProvider2.SetError(this.ch_password_tb, "please add username!!");
            }
            else
            {
                errorProvider2.Clear();
            }
        }


        //for confirm textbox
        private void ch_confirm_pas_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(ch_confirm_pas.Text) == true)
            {

                errorProvider3.SetError(this.ch_confirm_pas, "please add username!!");
            }
            else
            {
                errorProvider3.Clear();
            }
        }

        //change passord button
        private void change_Button_ch_Click(object sender, EventArgs e)
        {
            string ch_username, ch_pass, ch_confirm_pass;

            ch_username = ch_username_tb.Text;
            ch_pass =ch_password_tb.Text;
            ch_confirm_pass=ch_confirm_pas.Text;


            //check fields are not empty
            if (ch_username_tb.Text.Length == 0 || ch_password_tb.Text.Length == 0 || ch_confirm_pas.Text.Length == 0)
            {
                MessageBox.Show("Please Fill every blank space!!", "Warning!", MessageBoxButtons.OK);
            }
            else
            {
                string q = "select * from user_info where [username] = '" + ch_username_tb.Text + "'";
                SqlDataAdapter sda = new SqlDataAdapter(q, SqlConnection);
                DataTable dt = new DataTable();
                sda.Fill(dt);


                if (dt.Rows.Count == 1)
                {

                    if (ch_pass == ch_confirm_pass)
                    {
                        
                        SqlCommand cmd = new SqlCommand("UPDATE user_info SET password = '" + ch_password_tb.Text + "' where username = '" + ch_username_tb.Text + "'", SqlConnection);


                        cmd.ExecuteNonQuery();
                        
                        MessageBox.Show("Password updated successfully");
                        this.Hide();
                        Loginn l = new Loginn();
                        l.ShowDialog();
                    }
                    else
                    {
                        MessageBox.Show("Password and confrim password are not same");


                    }


                }
                else
                {
                    MessageBox.Show("No such user exist","Warning");
                }

            }


        }
    }
}
