﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace WindowsFormsApp1
{
    public partial class signUP : Form
    {

        // for database
        SqlConnection SqlConnection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\HP\Desktop\try3.0\WindowsFormsApp1\user_details.mdf;Integrated Security=True");
        SqlCommand sql = new SqlCommand();

        public signUP()
        {
            InitializeComponent();
        }

        private void signUP_Load(object sender, EventArgs e)
        {
            try
            {
                SqlConnection.Open();
            }catch
            {
                MessageBox.Show("Connection to the database failed!", "Error", MessageBoxButtons.OK);
            }


        }


        //signup button
        private void guna2Button1_Click(object sender, EventArgs e)
        {
            try
            {
                string firstName, lastName, username, email, password, phone_num, confirm_pass;


                firstName = f_name_tb.Text;
                lastName = L_name_tb.Text;
                username = username_tb.Text;
                email = email_tb.Text;
                password = pass_tb.Text;
                phone_num = phnum_tb.Text;
                confirm_pass = confirm_pass_tb.Text;

                //phone number length
                if (phnum_tb.Text.Length != 11)
                {
                    MessageBox.Show("Phone number must have 11 digits!!!", "Warning!", MessageBoxButtons.OK);
                }

         
                if (f_name_tb.Text.Length == 0 || L_name_tb.Text.Length == 0 || username_tb.Text.Length == 0
                    || email_tb.Text.Length == 0 || pass_tb.Text.Length == 0 || phnum_tb.Text.Length == 0
                    || confirm_pass_tb.Text.Length == 0)
                {
                    MessageBox.Show("Please Fill every blank space!", "Warning!!!", MessageBoxButtons.OK);
                }
                else
                {
                   
                    //passwords must be 4 digits
                    if (pass_tb.Text.Length < 4) /////////////
                    {
                        MessageBox.Show("Password Must have atleast 4 characters!", "Warning!", MessageBoxButtons.OK);
                    }

                    else
                    {

                        if (password == confirm_pass)
                        {
                            // inserting into databass
                            string query = "Insert into [user_info]  ([First_name],[last_name],[username],[email],[password],[phone_number]) values" +
                                "('" + firstName + "','" + lastName + "','" + username + "','" + email + "','" + password + "','" + phone_num + "')";
                            sql = new SqlCommand(query, SqlConnection);
                            int rows = sql.ExecuteNonQuery();
                            MessageBox.Show("Account Created Successfully", "Success", MessageBoxButtons.OK);
                            phnum_tb.Clear();
                            pass_tb.Clear();
                            username_tb.Clear();
                            f_name_tb.Clear();
                            L_name_tb.Clear();
                            email_tb.Clear();
                            confirm_pass_tb.Clear();


                        }

                        else
                        {
                            MessageBox.Show("password and confirm password are not same !!!");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Username already existed!", "Error!!", MessageBoxButtons.OK);
            }
        }


        //phone number textbox validation==> accept only number
        private void phnum_tb_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

       

        //check for empty first name textbox
        private void f_name_tb_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(f_name_tb.Text) == true)
            {
                
                errorProvider1.SetError(this.f_name_tb, "please add first name!!");
            }
            else
            {
                errorProvider1.Clear();
            }
        }

        //check for empty last name textbox
        private void L_name_tb_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(L_name_tb.Text) == true)
            {
                
                errorProvider2.SetError(this.L_name_tb, "please add Last name!!");
            }
            else
            {
                errorProvider2.Clear();
            }
        }

        //for email textbox authentication
        string pattern = "^([0-9a-zA-Z]([-\\.\\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\\w]*[0-9a-zA-Z]\\.)+[a-zA-Z]{2,9})$";
        private void email_tb_Leave(object sender, EventArgs e)
        {
            if (Regex.IsMatch(email_tb.Text,pattern)==false)
            {
               
                errorProvider4.SetError(this.email_tb, "Invalid email!!");
            }
            else
            {
                errorProvider4.Clear();
            }
        }

        //for empty username check 
        private void username_tb_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(username_tb.Text) == true)
            {
             
                errorProvider3.SetError(this.username_tb, "please add username!!");
            }
            else
            {
                errorProvider3.Clear();
            }
        }

        //empty phone number textbox
        private void phnum_tb_Leave(object sender, EventArgs e)
        {
            //phone number must be 11 digit
            if (string.IsNullOrEmpty(phnum_tb.Text) == true)
            {

                errorProvider5.SetError(this.phnum_tb, "please add phone number");
            }
            
            else
            { 
                errorProvider5.Clear();
            }
        }

        //empty password textbox
        private void pass_tb_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(pass_tb.Text) == true)
            {

                errorProvider6.SetError(this.pass_tb, "please add password!!");
            }
            else
            {
                errorProvider6.Clear();
            }
        }


        //empty confirm pass text box
        private void confirm_pass_tb_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(confirm_pass_tb.Text) == true)
            {

                errorProvider7.SetError(this.confirm_pass_tb, "please add password!!");
            }
            else
            {
                errorProvider7.Clear();
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                pass_tb.PasswordChar = '\0';
                confirm_pass_tb.PasswordChar = '\0';

            }
            else
            {
                pass_tb.PasswordChar = '*';
                confirm_pass_tb.PasswordChar = '*';

            }
        }

        private void label5_Click(object sender, EventArgs e)
        {
            Loginn l = new Loginn();
            this.Hide();
            l.ShowDialog();
        }


        private void username_tb_Enter(object sender, EventArgs e)
        {
            
        }

        private void email_tb_Enter(object sender, EventArgs e)
        {
            
        }

        //to check already exited email in db
        public void for_unique_email()
        {
            string Email;

            Email = email_tb.Text;


            string query = "Select email from email where [email]='" + Email + "'";

            SqlDataAdapter sda = new SqlDataAdapter(query, SqlConnection);
            DataTable dataTable = new DataTable();


            if (dataTable.Rows.Count >= 1)
            {
                MessageBox.Show("Email already exists, use another email", "Error!!", MessageBoxButtons.OK);

            }
            else
            {
                MessageBox.Show("wrong credentials", "Error!!", MessageBoxButtons.OK);
            }
        }

        //to check already exited username in db
        public void for_unique_username()
        {
            string user_name;
            user_name = username_tb.Text;


            string query = "Select username from user_info where [username]='" + user_name + "'";

            SqlDataAdapter sda = new SqlDataAdapter(query, SqlConnection);
            DataTable dataTable = new DataTable();
         


            if (dataTable.Rows.Count >= 1)
            {
                MessageBox.Show("username already exists, try another one", "Error!!", MessageBoxButtons.OK);

            }
            else
            {
                MessageBox.Show("wrong credentials", "Error!!", MessageBoxButtons.OK);
            }

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
