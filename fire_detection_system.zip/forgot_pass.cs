﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;



namespace WindowsFormsApp1
{
    public partial class forgot_pass : Form
    {

        // for database connection
        SqlConnection SqlConnection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\HP\Desktop\try3.0\WindowsFormsApp1\user_details.mdf;Integrated Security=True");

        public forgot_pass()
        {
            InitializeComponent();
        }


        //back button forgot password
        private void guna2Button1_Click(object sender, EventArgs e)
        {
            Loginn ff = new Loginn();
            this.Hide();
            ff.ShowDialog();
        }


        //for username,forgot password form
        private void f_username_tb_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(f_username_tb.Text) == true)
            {

                errorProvider1.SetError(this.f_username_tb, "please add username!!");
            }
            else
            {
                errorProvider1.Clear();
            }
        }

        //for password, forgot password form
        private void f_password_tb_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(f_password_tb.Text) == true)
            {

                errorProvider2.SetError(this.f_password_tb, "please add username!!");
            }
            else
            {
                errorProvider2.Clear();
            }
        }


        //for confirm pass
        private void f_confirm_pas_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(f_confirm_pas.Text) == true)
            {

                errorProvider3.SetError(this.f_confirm_pas, "please add username!!");
            }
            else
            {
                errorProvider3.Clear();
            }

        }

        //check box 
        private void check_box_pas_forgot_CheckedChanged(object sender, EventArgs e)
        {
            if (check_box_pas_forgot.Checked)
            {
                f_password_tb.PasswordChar = '\0';
                f_confirm_pas.PasswordChar = '\0';

            }
            else
            {
                f_password_tb.PasswordChar = '*';
                f_confirm_pas.PasswordChar = '*';

            }
        }

        //change password button
        private void change_Button_Click(object sender, EventArgs e)
        {
            string f_username, f_passwrd, f_confirmPAss;

            f_username = f_username_tb.Text;

            f_passwrd = f_password_tb.Text;

            f_confirmPAss = f_confirm_pas.Text;


            //check fields are not empty
            if (f_username_tb.Text.Length == 0 || f_password_tb.Text.Length == 0 || f_confirm_pas.Text.Length == 0)
            {
                MessageBox.Show("Please Fill every blank space!!", "Warning!", MessageBoxButtons.OK);
            }
            else
            {
                string q = "select * from user_info where [username] = '" + f_username_tb.Text + "'";
                SqlDataAdapter sda = new SqlDataAdapter(q, SqlConnection);
                DataTable dt = new DataTable();
                sda.Fill(dt);


                if (dt.Rows.Count == 1)
                {

                    if (f_passwrd == f_confirmPAss)
                    {

                        SqlCommand cmd = new SqlCommand("UPDATE user_info SET password = '" + f_password_tb.Text + "' where username = '" + f_username_tb.Text + "'", SqlConnection);


                        cmd.ExecuteNonQuery();

                        MessageBox.Show("Password updated successfully");
                    }
                    else
                    {
                        MessageBox.Show("Password and confrim password are not same");

                    }


                }
                else
                {
                    MessageBox.Show("No such user exist", "Warning");
                }
            }

        }

        private void forgot_pass_Load(object sender, EventArgs e)
        {
            // to check database connection
            try
            {
                SqlConnection.Open();
            }
            catch
            {
                MessageBox.Show("Connection to the database failed!", "Error", MessageBoxButtons.OK);
            }
            // to check database connection
        }
    }
    }

       
  