﻿using MailKit.Net.Smtp;
using MimeKit;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WindowsFormsApp1.Properties;
namespace WindowsFormsApp1
{
    class EMail
    {
        public static string SendEmail(string Message, string Subject, string To_Name, string To_Email)
        {
           
            try
            {
                var Mail = Settings.Default.UserEMail;
                var Server = Settings.Default.EMailServer;
                var Port = 587;
                var Password = Settings.Default.EMailPass;  
                
                //MessageBox.Show(Mail + "\n" + Server + "\n" + Port + "\n" + Password + "\n" + To_Email + "\n");
                if (!String.IsNullOrWhiteSpace(Mail))
                {
                    var message = new MimeMessage();
                    message.From.Add(new MailboxAddress("", Mail));
                    message.To.Add(new MailboxAddress(To_Name, To_Email));
                    message.Subject = Subject;
                    var builder = new BodyBuilder
                    {
                        TextBody = @"Reporting Email",
                        HtmlBody = Message
                    };
                    message.Body = builder.ToMessageBody();
                    using (var client = new SmtpClient())
                    {
                        try
                        {
                            client.ServerCertificateValidationCallback = (s, c, h, E) => true;
                            try
                            {
                                client.Connect(Server, Port, false);
                                try
                                {
                                    client.Authenticate(Mail, Password);
                                }
                                catch
                                {
                                    return "Unable to Authenticate with EMail Server. E-Mail or Password incorrect.";
                                }
                                try
                                {
                                    client.Send(message);
                                    return "Email Sent.";
                                }
                                catch
                                {
                                    return "Unable to send EMail please double check receiver's email address.";
                                }
                                finally
                                {
                                    client.Disconnect(true);
                                }

                            }
                            catch
                            {

                            }
                        }
                        catch
                        {
                            return "Unable to send EMail.";
                        }

                    }
                }
                else
                {
                    return "Commpany Sending email not set.";
                }
                return "";
            }
            catch
            {
                return "Error";
            }

        }
    }
}
