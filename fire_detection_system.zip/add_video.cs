﻿using MediaToolkit;
using MediaToolkit.Model;
using MediaToolkit.Options;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class add_video : Form
    {
        public add_video()
        {
            InitializeComponent();
            //to show window media player UI 
           // axWindowsMediaPlayer1.uiMode = "none";
        }

       
        //back button
        private void guna2Button2_Click(object sender, EventArgs e)
        {
            this.Close();
            
        }

        //getting frames 
        void GetFrames()
        {
            using (var engine = new Engine())
            {
                var mp4 = new MediaFile { Filename = video_path };

                engine.GetMetadata(mp4);

                var i = 0;
                while (i < mp4.Metadata.Duration.Seconds)
                {
                    var options = new ConversionOptions { Seek = TimeSpan.FromSeconds(i) };
                    var ImgPath = $"E:\\Output\\image-{i}.jpeg";
                    var outputFile = new MediaFile { Filename = ImgPath };
                    engine.GetThumbnail(mp4, outputFile, options);
                    pictureBox1.Image = Detector.Detect(Image.FromFile(ImgPath),false);
                    i++;
                }
            }
        }
        // open button
        string video_path;
        private void guna2Button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog opg = new OpenFileDialog() { Multiselect = false, Filter = "MP4 File|*.mp4|All File|*.*"};

            if (opg.ShowDialog()==DialogResult.OK)
            {
                video_path = opg.FileName;
                //axWindowsMediaPlayer1.URL = video_path;
            }


        }

        //play button
        private void guna2Button3_Click(object sender, EventArgs e)
        {
            //axWindowsMediaPlayer1.Ctlcontrols.play();
            GetFrames();
        }

        //stop btn
        private void guna2Button4_Click(object sender, EventArgs e)
        {
            //axWindowsMediaPlayer1.Ctlcontrols.stop();
        }


        //pause btn
        private void guna2Button5_Click(object sender, EventArgs e)
        {
           // axWindowsMediaPlayer1.Ctlcontrols.pause();
        }

        private void add_video_Load(object sender, EventArgs e)
        {

        }
    }
}
