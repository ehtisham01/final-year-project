﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace WindowsFormsApp1
{
    public partial class Loginn : Form
    {


        // for database connection
        SqlConnection SqlConnection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\HP\Desktop\try3.0\WindowsFormsApp1\user_details.mdf;Integrated Security=True");

        public Loginn()
        {
            InitializeComponent();
        }

        //show password checkbox
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (check_box_pas_fom1.Checked)
            {
                password_tb.PasswordChar = '\0';

            }
            else
            {
                password_tb.PasswordChar = '*';

            }
        }

        //creeate account label 
        private void label5_Click(object sender, EventArgs e)
        {
            signUP l = new signUP();
            this.Hide();
            l.ShowDialog();
        }

        private void Loginn_Load(object sender, EventArgs e)
        {
            // to check database connection
            try
            {
                SqlConnection.Open();
            }
            catch
            {
                MessageBox.Show("Connection to the database failed!", "Error", MessageBoxButtons.OK);
            }
            // to check database connection



            //remember me code
            if (Properties.Settings.Default.Username != string.Empty)
            {
                u_em_tb.Text = Properties.Settings.Default.Username;
                password_tb.Text = Properties.Settings.Default.Password;
            }
            //remember me code

        }

        //login button
        private void login_Button_Click(object sender, EventArgs e)
        {
            //remember me checkbox code
            if (remember_Chck.Checked==true) 
            {
                Properties.Settings.Default.Username = u_em_tb.Text;

                Properties.Settings.Default.Password = password_tb.Text;

                Properties.Settings.Default.Save();

            }
            if (remember_Chck.Checked==false)
            {
                Properties.Settings.Default.Username = "";

                Properties.Settings.Default.Password = "";

                Properties.Settings.Default.Save();

            }






            //////////////////////////////////////////////////////
            ///

            string username = u_em_tb.Text;
            string password = password_tb.Text;

            if (u_em_tb.Text.Length == 0 || password_tb.Text.Length == 0 )
            {
                MessageBox.Show("Please Fill every blank space!");
            }
            else
            {
                string query = "select * from user_info where [username]='" + username + "' and [password]='" + password + "'";
                SqlDataAdapter sda = new SqlDataAdapter(query, SqlConnection);
                DataTable dataTable = new DataTable();
                sda.Fill(dataTable);

                if (dataTable.Rows.Count == 1)
                {
                    //MessageBox.Show("Sign in successfull!!", "Success");
                    stream ff = new stream();
                    this.Hide();
                    ff.ShowDialog();

                }
                else
                {
                    MessageBox.Show("wrong credentials", "Error!!", MessageBoxButtons.OK);
                }
            }
        }

        //for empty username textbox
        private void u_em_tb_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(u_em_tb.Text) == true)
            {
                
                errorProvider1.SetError(this.u_em_tb, "please add username!!");
            }
            else
            {
                errorProvider1.Clear();
            }
        }


        //for empty password textbox
        private void password_tb_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(password_tb.Text) == true)
            {

                errorProvider2.SetError(this.password_tb, "please add password!!");
            }
            else
            {
                errorProvider2.Clear();
            }
        }

        //forgot password label
        private void label3_Click(object sender, EventArgs e)
        {
            forgot_pass ff = new forgot_pass();
            this.Hide();
            ff.ShowDialog();
      
        }

        

        private void remember_Chck_CheckedChanged(object sender, EventArgs e)
        {
            
        }
    }
}
