﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class user_detail_form : Form
    {
        public user_detail_form()
        {
            InitializeComponent();
        }

        //back button
        private void guna2Button1_Click(object sender, EventArgs e)
        {
            stream ss = new stream();
            this.Hide();
            ss.ShowDialog();
        }

       
    }
}
