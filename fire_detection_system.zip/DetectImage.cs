﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class DetectImage : Form
    {
        public DetectImage()
        {
            InitializeComponent();
        }


        //open button
        private void BtnOpenImage_Click(object sender, EventArgs e)
        {
            OpenFileDialog opg = new OpenFileDialog() { Multiselect = false, Filter = "JPEG File|*.jpg|All File|*.*" };

            if (opg.ShowDialog() == DialogResult.OK)
            {
                var ImagePath = opg.FileName;
                PBOrignalImage.Image = Image.FromFile(ImagePath);
            }
        }


        //detect button
        private void guna2Button5_Click(object sender, EventArgs e)
        {
            PBProcessedImage.Image = Detector.Detect(PBOrignalImage.Image, false);
        }


        //back button
        private void BtnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
