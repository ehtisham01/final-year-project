﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp1.Properties;

namespace WindowsFormsApp1
{
    public partial class EMailSettings : Form
    {
        public EMailSettings()
        {
            InitializeComponent();
        }

        //okay button
        private void BtnOK_Click(object sender, EventArgs e)
        {
            Settings.Default.EMailPass = TBEMailAdress.Text;
            Settings.Default.EMailServer = TBServerAddress.Text;
            Settings.Default.EMailPass = TBPassword.Text;
            Settings.Default.EMailUser = TBUserName.Text;
            Settings.Default.UserEMail = TBEMailAdress.Text;
            Settings.Default.Save();
            this.Hide();
            DialogResult = DialogResult.OK;
        }

        //back button
        private void guna2Button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            DialogResult = DialogResult.Abort;
        }


        //form load
        private void EMailSettings_Load(object sender, EventArgs e)
        {
            TBEMailAdress.Text = Settings.Default.EMailPass;
            TBServerAddress.Text = Settings.Default.EMailServer;
            TBPassword.Text = Settings.Default.EMailPass;
            TBUserName.Text = Settings.Default.EMailUser;
            TBEMailAdress.Text = Settings.Default.UserEMail;
        }
    }
}
