﻿
namespace WindowsFormsApp1
{
    partial class DetectImage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DetectImage));
            this.BtnBack = new Guna.UI2.WinForms.Guna2Button();
            this.BtnOpenImage = new Guna.UI2.WinForms.Guna2Button();
            this.PBOrignalImage = new System.Windows.Forms.PictureBox();
            this.PBProcessedImage = new System.Windows.Forms.PictureBox();
            this.BtnDetectImage = new Guna.UI2.WinForms.Guna2Button();
            ((System.ComponentModel.ISupportInitialize)(this.PBOrignalImage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBProcessedImage)).BeginInit();
            this.SuspendLayout();
            // 
            // BtnBack
            // 
            this.BtnBack.Animated = true;
            this.BtnBack.BackColor = System.Drawing.Color.Transparent;
            this.BtnBack.BorderRadius = 8;
            this.BtnBack.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.BtnBack.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.BtnBack.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.BtnBack.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.BtnBack.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.BtnBack.ForeColor = System.Drawing.Color.White;
            this.BtnBack.Location = new System.Drawing.Point(12, 563);
            this.BtnBack.MaximumSize = new System.Drawing.Size(58, 36);
            this.BtnBack.MinimumSize = new System.Drawing.Size(58, 36);
            this.BtnBack.Name = "BtnBack";
            this.BtnBack.Size = new System.Drawing.Size(58, 36);
            this.BtnBack.TabIndex = 20;
            this.BtnBack.Text = "Back";
            this.BtnBack.UseTransparentBackground = true;
            this.BtnBack.Click += new System.EventHandler(this.BtnBack_Click);
            // 
            // BtnOpenImage
            // 
            this.BtnOpenImage.Animated = true;
            this.BtnOpenImage.BackColor = System.Drawing.Color.Transparent;
            this.BtnOpenImage.BorderRadius = 8;
            this.BtnOpenImage.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.BtnOpenImage.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.BtnOpenImage.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.BtnOpenImage.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.BtnOpenImage.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.BtnOpenImage.ForeColor = System.Drawing.Color.White;
            this.BtnOpenImage.Location = new System.Drawing.Point(207, 518);
            this.BtnOpenImage.MaximumSize = new System.Drawing.Size(58, 36);
            this.BtnOpenImage.MinimumSize = new System.Drawing.Size(58, 36);
            this.BtnOpenImage.Name = "BtnOpenImage";
            this.BtnOpenImage.Size = new System.Drawing.Size(58, 36);
            this.BtnOpenImage.TabIndex = 20;
            this.BtnOpenImage.Text = "Open";
            this.BtnOpenImage.UseTransparentBackground = true;
            this.BtnOpenImage.Click += new System.EventHandler(this.BtnOpenImage_Click);
            // 
            // PBOrignalImage
            // 
            this.PBOrignalImage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.PBOrignalImage.Location = new System.Drawing.Point(12, 12);
            this.PBOrignalImage.Name = "PBOrignalImage";
            this.PBOrignalImage.Size = new System.Drawing.Size(500, 500);
            this.PBOrignalImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBOrignalImage.TabIndex = 21;
            this.PBOrignalImage.TabStop = false;
            // 
            // PBProcessedImage
            // 
            this.PBProcessedImage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.PBProcessedImage.Location = new System.Drawing.Point(559, 12);
            this.PBProcessedImage.Name = "PBProcessedImage";
            this.PBProcessedImage.Size = new System.Drawing.Size(500, 500);
            this.PBProcessedImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBProcessedImage.TabIndex = 21;
            this.PBProcessedImage.TabStop = false;
            // 
            // BtnDetectImage
            // 
            this.BtnDetectImage.Animated = true;
            this.BtnDetectImage.BackColor = System.Drawing.Color.Transparent;
            this.BtnDetectImage.BorderRadius = 8;
            this.BtnDetectImage.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.BtnDetectImage.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.BtnDetectImage.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.BtnDetectImage.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.BtnDetectImage.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.BtnDetectImage.ForeColor = System.Drawing.Color.White;
            this.BtnDetectImage.Location = new System.Drawing.Point(792, 518);
            this.BtnDetectImage.Name = "BtnDetectImage";
            this.BtnDetectImage.Size = new System.Drawing.Size(68, 36);
            this.BtnDetectImage.TabIndex = 22;
            this.BtnDetectImage.Text = "Detect";
            this.BtnDetectImage.UseTransparentBackground = true;
            this.BtnDetectImage.Click += new System.EventHandler(this.guna2Button5_Click);
            // 
            // DetectImage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(1092, 611);
            this.Controls.Add(this.BtnDetectImage);
            this.Controls.Add(this.PBProcessedImage);
            this.Controls.Add(this.PBOrignalImage);
            this.Controls.Add(this.BtnOpenImage);
            this.Controls.Add(this.BtnBack);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1108, 650);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(1108, 650);
            this.Name = "DetectImage";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Detect Image";
            ((System.ComponentModel.ISupportInitialize)(this.PBOrignalImage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBProcessedImage)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private Guna.UI2.WinForms.Guna2Button BtnBack;
        private Guna.UI2.WinForms.Guna2Button BtnOpenImage;
        private System.Windows.Forms.PictureBox PBOrignalImage;
        private System.Windows.Forms.PictureBox PBProcessedImage;
        private Guna.UI2.WinForms.Guna2Button BtnDetectImage;
    }
}