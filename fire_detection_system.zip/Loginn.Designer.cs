﻿
namespace WindowsFormsApp1
{
    partial class Loginn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Loginn));
            this.guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.remember_Chck = new System.Windows.Forms.CheckBox();
            this.check_box_pas_fom1 = new System.Windows.Forms.CheckBox();
            this.u_em_tb = new Guna.UI2.WinForms.Guna2TextBox();
            this.password_tb = new Guna.UI2.WinForms.Guna2TextBox();
            this.login_Button = new Guna.UI2.WinForms.Guna2Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider2 = new System.Windows.Forms.ErrorProvider(this.components);
            this.guna2Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).BeginInit();
            this.SuspendLayout();
            // 
            // guna2Panel1
            // 
            this.guna2Panel1.Controls.Add(this.pictureBox1);
            this.guna2Panel1.Controls.Add(this.remember_Chck);
            this.guna2Panel1.Controls.Add(this.check_box_pas_fom1);
            this.guna2Panel1.Controls.Add(this.u_em_tb);
            this.guna2Panel1.Controls.Add(this.password_tb);
            this.guna2Panel1.Controls.Add(this.login_Button);
            this.guna2Panel1.Controls.Add(this.label5);
            this.guna2Panel1.Controls.Add(this.label4);
            this.guna2Panel1.Controls.Add(this.label3);
            this.guna2Panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.guna2Panel1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.guna2Panel1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.guna2Panel1.Location = new System.Drawing.Point(0, 0);
            this.guna2Panel1.MaximumSize = new System.Drawing.Size(693, 561);
            this.guna2Panel1.MinimumSize = new System.Drawing.Size(693, 561);
            this.guna2Panel1.Name = "guna2Panel1";
            this.guna2Panel1.Size = new System.Drawing.Size(693, 561);
            this.guna2Panel1.TabIndex = 1;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(207, 25);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(296, 78);
            this.pictureBox1.TabIndex = 12;
            this.pictureBox1.TabStop = false;
            // 
            // remember_Chck
            // 
            this.remember_Chck.AutoSize = true;
            this.remember_Chck.BackColor = System.Drawing.Color.Transparent;
            this.remember_Chck.Checked = true;
            this.remember_Chck.CheckState = System.Windows.Forms.CheckState.Checked;
            this.remember_Chck.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.remember_Chck.ForeColor = System.Drawing.Color.White;
            this.remember_Chck.Location = new System.Drawing.Point(382, 291);
            this.remember_Chck.Name = "remember_Chck";
            this.remember_Chck.Size = new System.Drawing.Size(104, 19);
            this.remember_Chck.TabIndex = 11;
            this.remember_Chck.Text = "Remember me";
            this.remember_Chck.UseVisualStyleBackColor = false;
            this.remember_Chck.CheckedChanged += new System.EventHandler(this.remember_Chck_CheckedChanged);
            // 
            // check_box_pas_fom1
            // 
            this.check_box_pas_fom1.AutoSize = true;
            this.check_box_pas_fom1.BackColor = System.Drawing.Color.Transparent;
            this.check_box_pas_fom1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.check_box_pas_fom1.ForeColor = System.Drawing.Color.White;
            this.check_box_pas_fom1.Location = new System.Drawing.Point(243, 291);
            this.check_box_pas_fom1.Name = "check_box_pas_fom1";
            this.check_box_pas_fom1.Size = new System.Drawing.Size(108, 19);
            this.check_box_pas_fom1.TabIndex = 10;
            this.check_box_pas_fom1.Text = "Show password";
            this.check_box_pas_fom1.UseVisualStyleBackColor = false;
            this.check_box_pas_fom1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // u_em_tb
            // 
            this.u_em_tb.Animated = true;
            this.u_em_tb.BackColor = System.Drawing.Color.Transparent;
            this.u_em_tb.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.u_em_tb.BorderColor = System.Drawing.Color.White;
            this.u_em_tb.BorderRadius = 8;
            this.u_em_tb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.u_em_tb.DefaultText = "";
            this.u_em_tb.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.u_em_tb.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.u_em_tb.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.u_em_tb.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.u_em_tb.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.u_em_tb.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.u_em_tb.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.u_em_tb.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.u_em_tb.Location = new System.Drawing.Point(243, 164);
            this.u_em_tb.Name = "u_em_tb";
            this.u_em_tb.PasswordChar = '\0';
            this.u_em_tb.PlaceholderForeColor = System.Drawing.Color.White;
            this.u_em_tb.PlaceholderText = "Username ";
            this.u_em_tb.SelectedText = "";
            this.u_em_tb.Size = new System.Drawing.Size(222, 36);
            this.u_em_tb.TabIndex = 0;
            this.u_em_tb.Leave += new System.EventHandler(this.u_em_tb_Leave);
            // 
            // password_tb
            // 
            this.password_tb.Animated = true;
            this.password_tb.BackColor = System.Drawing.Color.Transparent;
            this.password_tb.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.password_tb.BorderColor = System.Drawing.Color.White;
            this.password_tb.BorderRadius = 8;
            this.password_tb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.password_tb.DefaultText = "";
            this.password_tb.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.password_tb.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.password_tb.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.password_tb.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.password_tb.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.password_tb.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.password_tb.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.password_tb.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.password_tb.Location = new System.Drawing.Point(243, 228);
            this.password_tb.Name = "password_tb";
            this.password_tb.PasswordChar = '*';
            this.password_tb.PlaceholderForeColor = System.Drawing.Color.White;
            this.password_tb.PlaceholderText = "Password";
            this.password_tb.SelectedText = "";
            this.password_tb.Size = new System.Drawing.Size(222, 36);
            this.password_tb.TabIndex = 1;
            this.password_tb.Leave += new System.EventHandler(this.password_tb_Leave);
            // 
            // login_Button
            // 
            this.login_Button.Animated = true;
            this.login_Button.BackColor = System.Drawing.Color.Transparent;
            this.login_Button.BorderRadius = 8;
            this.login_Button.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.login_Button.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.login_Button.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.login_Button.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.login_Button.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.login_Button.ForeColor = System.Drawing.Color.White;
            this.login_Button.Location = new System.Drawing.Point(307, 331);
            this.login_Button.Name = "login_Button";
            this.login_Button.Size = new System.Drawing.Size(108, 36);
            this.login_Button.TabIndex = 3;
            this.login_Button.Text = "login";
            this.login_Button.UseTransparentBackground = true;
            this.login_Button.Click += new System.EventHandler(this.login_Button_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label5.Font = new System.Drawing.Font("Segoe UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(380, 435);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(61, 15);
            this.label5.TabIndex = 7;
            this.label5.Text = "click here";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label4.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(273, 435);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(111, 15);
            this.label4.TabIndex = 6;
            this.label4.Text = "if you are new then,";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label3.Font = new System.Drawing.Font("Segoe UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(312, 393);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(99, 15);
            this.label3.TabIndex = 5;
            this.label3.Text = "Forgot password";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // errorProvider2
            // 
            this.errorProvider2.ContainerControl = this;
            // 
            // Loginn
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(694, 561);
            this.Controls.Add(this.guna2Panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(710, 600);
            this.MinimumSize = new System.Drawing.Size(710, 600);
            this.Name = "Loginn";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Login";
            this.Load += new System.EventHandler(this.Loginn_Load);
            this.guna2Panel1.ResumeLayout(false);
            this.guna2Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private Guna.UI2.WinForms.Guna2Button login_Button;
        private Guna.UI2.WinForms.Guna2TextBox u_em_tb;
        private Guna.UI2.WinForms.Guna2TextBox password_tb;
        private System.Windows.Forms.CheckBox check_box_pas_fom1;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.ErrorProvider errorProvider2;
        private System.Windows.Forms.CheckBox remember_Chck;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}